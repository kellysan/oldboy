#! /usr/bin/env python
# -*- coding: utf-8 -*-

#    File Name：       dytt
#    Description :
#    Author :          SanYapeng
#    date：            2019-04-28
#    Change Activity:  2019-04-28:


from urllib.request import urlopen
import requests
import re
import ssl
import os
import time
ssl._create_default_https_context = ssl._create_unverified_context


base_domain_name = "https://www.dytt8.net/"
headers = {'User-Agent': 'User-Agent:Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36'}
##
## 详情 details
def dytt(urlinfo,rgx):
    """
    基础函数用来执行打开网页
    :param urlinfo: url信息
    :param rgx: 正则匹配信息
    :return: 返回匹配到的可迭代信息
    """
    content = requests.get(urlinfo, headers=headers)
    content.encoding = "gbk"
    #content = urlopen(urlinfo).read().decode("gbk")
    #print(content.text)
    return rgx.finditer(content.text)



def get_details_url():
    dytt_details_rgx = re.compile(r"(?P<page>/\w+/gndy/dyzz/\d+/\d+.html)", re.S)
    dytt_new_rgx = re.compile(r"<!--{start:最新电影-->(.*?)<!--}end:最新电影-->", re.S)
    details_info = dytt(base_domain_name, dytt_new_rgx)
    for page in details_info:

        details_uri = dytt_details_rgx.finditer(page.group())
        for uri in details_uri:
            yield base_domain_name + uri.group("page")


def get_move_info():
    pattern = re.compile(r'<br />◎译.*?名(?P<name>.*?)◎片.*?名.*?◎主.*?演(?P<actor>.*?)(◎标.*?签|◎简.*?介).*?<td style="WORD-WRAP: break-word" bgcolor="#fdfddf"><a href=(?P<loadURL>.*?)>', re.S)
    movie_info_list = []
    actor_list = []
    for url in get_details_url():
        it = dytt(url, pattern)
        movie_info_dict = {}
        for item in it:
            #movie_info_dict["name"] = item.group("name").strip('<br />')
            actor = item.group("actor").replace('&middot;','·').strip('<br />').split('<br />')
            for k in actor:
                k = k.strip()
                actor_list.append(el)
            movie_info_dict['actor'] = actor_list
            movie_info_dict["url"] = item.group("loadURL").strip()
        movie_info_list.append(movie_info_dict)
    return movie_info_list

if __name__ == '__main__':
    for i in get_move_info():
        print(i)